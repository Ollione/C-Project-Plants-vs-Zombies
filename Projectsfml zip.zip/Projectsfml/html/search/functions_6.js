var searchData=
[
  ['inittextures_0',['inittextures',['../class_game_map.html#a3f7fc4a63ff848a3cdc97f73002ec343',1,'GameMap']]],
  ['isgameover_1',['isGameOver',['../classgame.html#a74cf5ba378bd76a1446e29cd928fbcef',1,'game']]]
];
