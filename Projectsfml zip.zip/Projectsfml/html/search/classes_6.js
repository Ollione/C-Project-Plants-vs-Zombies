var searchData=
[
  ['regular_5fzombie_0',['Regular_Zombie',['../class_regular___zombie.html',1,'']]]
];
