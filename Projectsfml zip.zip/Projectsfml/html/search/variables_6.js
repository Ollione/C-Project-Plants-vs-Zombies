var searchData=
[
  ['team_0',['Team',['../classentity.html#a1ff3515b4f25d9d1ad47808e0176b83a',1,'entity']]],
  ['textures_1',['textures',['../class_regular___zombie.html#a3dac06cee7e4d243c4eaee4371b9189c',1,'Regular_Zombie']]]
];
