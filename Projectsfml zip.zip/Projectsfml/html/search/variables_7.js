var searchData=
[
  ['walkanimation_0',['Walkanimation',['../class_regular___zombie.html#a7621506b4fc4daa4a596d629980d6d04',1,'Regular_Zombie']]],
  ['window_1',['window',['../classentity.html#aa480e6f5b4f0bca0a556afa4942893ff',1,'entity']]]
];
