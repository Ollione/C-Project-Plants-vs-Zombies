var searchData=
[
  ['damage_0',['damage',['../class_regular___zombie.html#a08b770949aa3b488cffc99e3fb4b4115',1,'Regular_Zombie']]],
  ['deleteflag_1',['deleteFlag',['../classentity.html#a18bb0d73c352055383e590f7a56c2e5f',1,'entity']]]
];
