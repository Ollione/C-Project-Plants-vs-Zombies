var searchData=
[
  ['health_0',['health',['../class_regular___zombie.html#aa9ca0e36270ab2755315670706a391e2',1,'Regular_Zombie']]]
];
