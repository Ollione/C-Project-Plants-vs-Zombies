var searchData=
[
  ['bucket_5fzombie_0',['Bucket_Zombie',['../class_bucket___zombie.html#a092d36b22cf4628019eb2f7f4572491d',1,'Bucket_Zombie']]]
];
