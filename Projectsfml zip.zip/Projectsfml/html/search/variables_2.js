var searchData=
[
  ['gameinstance_0',['gameInstance',['../class_regular___zombie.html#af71f2d6d93d37be1abcf723026e2d319',1,'Regular_Zombie']]]
];
