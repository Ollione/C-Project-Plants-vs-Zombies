var searchData=
[
  ['flagfordelete_0',['flagfordelete',['../classentity.html#a981cc37bf40a6c5697496ad056f9ab38',1,'entity']]]
];
