var searchData=
[
  ['attackanimation_0',['Attackanimation',['../class_regular___zombie.html#a1ddfdb8b72f69dd38cc85970c8a352d0',1,'Regular_Zombie']]]
];
