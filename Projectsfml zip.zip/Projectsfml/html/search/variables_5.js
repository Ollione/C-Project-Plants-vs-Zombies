var searchData=
[
  ['speed_0',['speed',['../class_regular___zombie.html#a0c53ab6989b7cf6a0f3f00f33413ea09',1,'Regular_Zombie']]],
  ['sprite_1',['sprite',['../class_regular___zombie.html#a73af035564accdb0a9003b7fbfb011f7',1,'Regular_Zombie']]]
];
