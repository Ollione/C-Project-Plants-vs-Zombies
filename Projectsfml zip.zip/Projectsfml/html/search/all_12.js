var searchData=
[
  ['ypos_0',['ypos',['../classentity.html#a76b938f9cc791915d2b25730af922cdc',1,'entity']]]
];
