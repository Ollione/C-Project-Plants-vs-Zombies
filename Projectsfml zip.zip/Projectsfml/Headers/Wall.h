/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_WALL_H
#define PROJECTSFML_WALL_H

#include "entity.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Textures.h"
#include "Animations.h"
#include "GameMap.h"
#include "game.h"
#include <memory>

/**
 * @class Wall
 * @brief Wall entity which functions as a shield for the lane. It has a large health pool and works as a time sink for the zombies so the pea shooters have a longer time to kill them.
 */
class Wall : public entity {
public:
    /**
     * @brief Constructor for the Wall class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the Wall.
     * @param y The y-coordinate of the Wall.
     * @param window The window to render the Wall.
     * @param textures The texture manager to load the textures.
     */
    Wall(std::string namein, int x, int y, sf::RenderWindow *window, TextureManager *textures);

    /**
     * @brief Destructor for the Wall class.
     */
    ~Wall() override;

    /**
     * @brief Updates the Wall. Updates the animation of the Wall, which changes depending on its health.
     */
    void update() override;

    /**
     * @brief Renders the Wall, including its animation frame.
     */
    void renderentity() override;

    /**
     * @brief Changes the health of the Wall. Flags it for deletion if it is dead.
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;

private:
    sf::Clock clock; ///< Clock to keep track of the time
    int health = 300; ///< Health of the Wall
    TextureManager *textures; ///< TextureManager to load the texture
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the Wall
    std::unique_ptr<Animation> idleanimation; ///< Animation of the Wall
    std::unique_ptr<Animation> idleanimationDmged1; ///< Animation of the Wall when damaged
    std::unique_ptr<Animation> idleanimationDmged2; ///< Animation of the Wall when damaged
};

#endif //PROJECTSFML_WALL_H
