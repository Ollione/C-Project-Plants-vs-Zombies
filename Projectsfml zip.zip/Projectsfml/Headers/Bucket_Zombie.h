/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_BUCKET_ZOMBIE_H
#define PROJECTSFML_BUCKET_ZOMBIE_H

#include "entity.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Textures.h"
#include "Animations.h"
#include "GameMap.h"
#include "Regular_Zombie.h" // Include the Regular_Zombie.h file here
#include "game.h" // Include the game.h file here

/**
 * @class Bucket_Zombie
 * @brief Enemy entity which inherits from Regular_Zombie class.
 *
 * A zombie with a bucket on its head, having more health and dealing more damage than a Regular_Zombie.
 */
class Bucket_Zombie : public Regular_Zombie {
public:
    /**
     * @brief Constructor for Bucket_Zombie class.
     *
     * Initializes a Bucket_Zombie with specified parameters.
     *
     * @param namein The name of the zombie.
     * @param x The x-coordinate of the zombie's position.
     * @param y The y-coordinate of the zombie's position.
     * @param window Pointer to the SFML RenderWindow.
     * @param textures Pointer to the TextureManager for loading textures.
     * @param gameInstance Pointer to the current game instance.
     */
    Bucket_Zombie(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, game* gameInstance);

    /**
     * @brief Destructor for Bucket_Zombie class.
     */
    ~Bucket_Zombie() override;

    /**
     * @brief Updates the Bucket_Zombie.
     *
     * Mainly uses the parent update function with additional logic specific to Bucket_Zombie.
     */
    void update() override;

    /**
     * @brief Renders the Bucket_Zombie.
     *
     * Uses the parent renderentity function with additional logic specific to Bucket_Zombie.
     */
    void renderentity() override;

    /**
     * @brief Changes the health of the Bucket_Zombie.
     *
     * Uses the parent hpchange function with additional logic specific to Bucket_Zombie.
     *
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;
};

#endif //PROJECTSFML_BUCKET_ZOMBIE_H