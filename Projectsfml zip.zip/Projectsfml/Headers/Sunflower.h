/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_SUNFLOWER_H
#define PROJECTSFML_SUNFLOWER_H

#include "entity.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Textures.h"
#include "Animations.h"
#include "GameMap.h"
#include "game.h"
#include <memory>

class game;

/**
 * @class Sunflower
 * @brief Sunflower entity which generates sun for the player to make it possible to plant more plants. The sunflower can't attack and is a support plant.
 */
class Sunflower : public entity {
public:
    /**
     * @brief Constructor for the Sunflower class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the Sunflower.
     * @param y The y-coordinate of the Sunflower.
     * @param window The window to render the Sunflower.
     * @param textures The texture manager to load the textures.
     * @param gameInstance The game instance to access the game's functions.
     */
    Sunflower(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, game* gameInstance);

    /**
     * @brief Destructor for the Sunflower class.
     */
    ~Sunflower() override;

    /**
     * @brief Updates the Sunflower. Checks if it should generate sun and calls the generateSun function if necessary.
     * Updates the animation of the Sunflower.
     */
    void update() override;

    /**
     * @brief Renders the Sunflower, including its animation frame.
     */
    void renderentity() override;

    /**
     * @brief Changes the health of the Sunflower. Flags it for deletion if it is dead.
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;

private:
    int health = 100; ///< Health of the Sunflower
    TextureManager* textures; ///< TextureManager to load the texture
    game* gameInstance; ///< Game instance to access the game's functions
    sf::Clock clock; ///< Clock to keep track of the time
    sf::Clock cooldownClock; ///< Clock to keep track of the cooldown
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the Sunflower
    std::unique_ptr<Animation> idleanimation; ///< Animation of the Sunflower

    /**
     * @brief Generates sun. Adds sun to the game's sun counter.
     */
    void generateSun();
};

#endif //PROJECTSFML_SUNFLOWER_H
