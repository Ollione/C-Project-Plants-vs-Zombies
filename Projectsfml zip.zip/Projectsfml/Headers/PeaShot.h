/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_PEASHOT_H
#define PROJECTSFML_PEASHOT_H

#include "entity.h"
#include <memory>

/**
 * @class PeaShot
 * @brief The PeaShot class functions as the main projectile of the game. It is shot by the PeaShooter and moves to the right, towards the incoming zombies.
 */
class PeaShot : public entity {
public:
    /**
     * @brief Constructor for the PeaShot class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the PeaShot.
     * @param y The y-coordinate of the PeaShot.
     * @param window The window to render the PeaShot.
     * @param textures The texture manager to load the textures.
     * @param damage The damage of the PeaShot.
     * @param speed The speed of the PeaShot.
     * @param speedInterval The interval at which the PeaShot moves.
     */
    PeaShot(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, int damage, int speed, sf::Time speedInterval);

    /**
     * @brief Destructor for the PeaShot class.
     */
    ~PeaShot() override;

    /**
     * @brief Updates the PeaShot. Moves the PeaShot to the right and checks if it is out of bounds. If it is out of bounds, it flags it for deletion.
     */
    void update() override;

    /**
     * @brief Renders the PeaShot. Renders the sprite of the PeaShot.
     */
    void renderentity() override;

    /**
     * @brief Gets the hitbox of the PeaShot.
     * @return The hitbox of the PeaShot.
     */
    [[nodiscard]] sf::Rect<float> getHitbox() const override;

    /**
     * @brief Gets the damage of the PeaShot.
     * @return The damage of the PeaShot.
     */
    int getdmg() const;

private:
    sf::Clock clock; ///< Clock to keep track of the time
    sf::Time speedInterval; ///< Time interval that determines how fast the PeaShot moves
    int speed; ///< Speed of the PeaShot, which determines how many pixels it moves per update
    int damage; ///< Damage of the PeaShot
    TextureManager* textures; ///< TextureManager to load the texture
    sf::Rect<float> hitbox; ///< Hitbox of the PeaShot
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the PeaShot
};

#endif //PROJECTSFML_PEASHOT_H
