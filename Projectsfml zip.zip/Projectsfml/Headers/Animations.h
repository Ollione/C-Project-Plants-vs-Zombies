/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_ANIMATIONS_H
#define PROJECTSFML_ANIMATIONS_H

#include <SFML/Graphics.hpp>
#include "Textures.h"
#include <memory>

/**
 * @class Animation
 * @brief Manages animations by updating frames at a specified speed.
 *
 * This class is designed to handle the animations within the game, allowing for the update of frames in a timely manner to create smooth animations. The speed of the animation is determined by the frame duration, and it can handle different frame counts and durations, providing flexibility for various animation requirements.
 */
class Animation {
public:
    /**
     * @brief Constructs an Animation object.
     *
     * Initializes the animation with a texture manager, texture filename, frame count, and frame duration.
     *
     * @param textureManager Pointer to the TextureManager for loading textures.
     * @param filename Path to the texture file.
     * @param frameCount Number of frames in the animation.
     * @param frameDuration Duration of each frame.
     */
    Animation(TextureManager* textureManager, const std::string& filename, int frameCount, sf::Time frameDuration);

    /**
     * @brief Destructs the Animation object.
     */
    ~Animation();

    /**
     * @brief Gets the current frame index.
     *
     * @return The current frame index.
     */
    [[nodiscard]] int getCurrentFrameIndex() const;

    /**
     * @brief Updates the animation.
     *
     * Advances the animation frame based on the elapsed time.
     *
     * @param deltaTime Time elapsed since the last update.
     */
    void update(sf::Time deltaTime);

    /**
     * @brief Gets the texture of the animation.
     *
     * @return Pointer to the animation's texture.
     */
    [[nodiscard]] sf::Texture* getTexture() const;

    /**
     * @brief Gets the current frame of the animation.
     *
     * @return The current frame as an sf::IntRect.
     */
    [[nodiscard]] sf::IntRect getCurrentFrame() const;

private:
    TextureManager* textureManager; ///< Pointer to the TextureManager.
    sf::Texture* texture; ///< Texture of the animation.
    int frameCount; ///< Number of frames in the animation.
    sf::Time frameDuration; ///< Duration of each frame.
    int currentFrame; ///< Index of the current frame.
    sf::Time elapsedTime; ///< Time elapsed since the last frame update.
    std::unique_ptr<sf::IntRect[]> frames; ///< Array of frame rectangles.
};

#endif //PROJECTSFML_ANIMATIONS_H