/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_TEXTURES_H
#define PROJECTSFML_TEXTURES_H

#include <SFML/Graphics.hpp>
#include <map>
#include <string>
#include <memory>

/**
 * @class TextureManager
 * @brief The TextureManager class handles the textures of the game. It loads the textures and stores them in a map.
 * The class is used to store all the textures in the game to prevent loading the same texture multiple times and wasting memory.
 */
class TextureManager {
public:
    /**
     * @brief Default constructor for the TextureManager class.
     */
    TextureManager() = default;

    /**
     * @brief Destructor for the TextureManager class. Deletes all the textures in the map.
     */
    ~TextureManager();

    /**
     * @brief Returns the texture pointer for the given filename. If the texture is not found, it loads the texture and returns it.
     * @param filename The name of the texture file.
     * @return A pointer to the texture.
     */
    sf::Texture* getTexture(const std::string& filename);

private:
    std::map<std::string, std::unique_ptr<sf::Texture>> textures; ///< Map to store the textures together with their filename
};

#endif //PROJECTSFML_TEXTURES_H
