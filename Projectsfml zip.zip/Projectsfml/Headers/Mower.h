/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_MOWER_H
#define PROJECTSFML_MOWER_H

#include "entity.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Textures.h"
#include "Animations.h"
#include "GameMap.h"
#include "game.h"
#include <memory>

/**
 * @class Mower
 * @brief Mower entity which functions as a cheat death for the player. It kills all zombies in its path when triggered.
 */
class Mower : public entity {
public:
    /**
     * @brief Constructor for the Mower class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the Mower.
     * @param y The y-coordinate of the Mower.
     * @param window The window to render the Mower.
     * @param textures The texture manager to load the textures.
     * @param gameInstance The game instance to access the game's functions.
     */
    Mower(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, game* gameInstance);

    /**
     * @brief Destructor for the Mower class.
     */
    ~Mower() override;

    /**
     * @brief Updates the Mower.
     */
    void update() override;

    /**
     * @brief Renders the Mower.
     */
    void renderentity() override;

    /**
     * @brief Changes the health of the Mower. Triggers killing mode when health is below 0.
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;

    /**
     * @brief Gets the hitbox of the Mower.
     * @return The hitbox of the Mower.
     */
    [[nodiscard]] sf::Rect<float> getHitbox() const override;

private:
    sf::Clock clock; ///< Clock to keep track of the time
    int health = 1; ///< Health of the Mower
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the Mower
    TextureManager* textures; ///< TextureManager to load the texture
    game* gameInstance; ///< Game instance to access the game's functions
    sf::Rect<float> hitbox; ///< Hitbox of the Mower
    bool wipeMode = false; ///< Wipe mode to trigger the killing mode

    /**
     * @brief Checks for zombies collision and kills them if they are in the hitbox of the Mower.
     */
    void checkForZombiesCollison();
};

#endif //PROJECTSFML_MOWER_H
