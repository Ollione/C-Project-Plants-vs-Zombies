/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_ENTITY_H
#define PROJECTSFML_ENTITY_H

#include <string>
#include <SFML/Graphics.hpp>
#include "Textures.h"

/**
 * @class entity
 * @brief The entity class is the base class for all the entities in the game. It contains the basic functions and variables that all entities should have.
 */
class entity {

public:
    /**
     * @brief Constructor for the entity class.
     * @param name The name of the entity.
     * @param x The x-coordinate of the entity.
     * @param y The y-coordinate of the entity.
     * @param window The window to render the entity.
     */
    entity(std::string name, int x, int y, sf::RenderWindow* window);

    /**
     * @brief Virtual destructor for the entity class.
     */
    virtual ~entity() = default;

    /**
     * @brief Pure virtual function to update the entity.
     */
    virtual void update() = 0;

    /**
     * @brief Pure virtual function to render the entity.
     */
    virtual void renderentity() = 0;

    /**
     * @brief Gets the y position of the entity.
     * @return The y position of the entity.
     */
    int getYpos() const;

    /**
     * @brief Gets the x position of the entity.
     * @return The x position of the entity.
     */
    int getXpos() const;

    /**
     * @brief Sets the delete flag to true so the entity can be deleted later on.
     */
    void flagfordelete();

    /**
     * @brief Gets the delete flag of the entity.
     * @return True if the entity should be deleted, otherwise false.
     */
    [[nodiscard]] bool getflagfordelete() const;

    /**
     * @brief Gets the hitbox of the entity.
     * @return The hitbox of the entity.
     */
    [[nodiscard]] virtual sf::Rect<float> getHitbox() const;

    /**
     * @brief Virtual function to change the health of the entity.
     * @param amount The amount to change the health by.
     */
    virtual void hpchange(int amount) {};

    /**
     * @brief Gets the name of the entity.
     * @return The name of the entity.
     */
    [[nodiscard]] std::string getName() const;

    /**
     * @brief Gets the team of the entity.
     * @return The team of the entity.
     */
    int getTeam() const;
private:
    std::string name;   ///< Name of the entity
protected:
    sf::RenderWindow* window;   ///< Window pointer to render the entity
    int xpos;   ///< X position of the entity
    int ypos;   ///< Y position of the entity
    bool deleteFlag = false;    ///< Flag to check if the entity should be deleted
    int Team = -1;  ///< Team of the entity
};

#endif //PROJECTSFML_ENTITY_H
