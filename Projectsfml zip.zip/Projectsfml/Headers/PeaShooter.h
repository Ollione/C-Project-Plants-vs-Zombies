/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_PEASHOOTER_H
#define PROJECTSFML_PEASHOOTER_H

#include "entity.h"
#include "Textures.h"
#include "SFML/Graphics.hpp"
#include "Animations.h"
#include "game.h"
#include <iostream>
#include <memory>

class game; // Needed for preloading declaration

/**
 * @class PeaShooter
 * @brief PeaShooter entity which functions as a tower in the game. It shoots peas at the zombies and defends the house.
 */
class PeaShooter : public entity {
public:
    /**
     * @brief Constructor for the PeaShooter class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the PeaShooter.
     * @param y The y-coordinate of the PeaShooter.
     * @param window The window to render the PeaShooter.
     * @param textures The texture manager to load the textures.
     * @param gameInstance The game instance to access the game's functions.
     */
    PeaShooter(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, game* gameInstance);

    /**
     * @brief Destructor for the PeaShooter class.
     */
    ~PeaShooter() override;

    /**
     * @brief Updates the PeaShooter. Checks if it should attack and calls the shoot function if necessary.
     * Flags it for deletion if it is dead. Manages cooldown and updates the animation.
     */
    void update() override;

    /**
     * @brief Renders the PeaShooter, including its animation frame.
     */
    void renderentity() override;

    /**
     * @brief Changes the health of the PeaShooter. Flags it for deletion if it is dead.
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;

private:
    sf::Clock clock; ///< Clock to keep track of the time
    bool attackFlag = false; ///< Flag to check if the PeaShooter is attacking
    int health = 100; ///< Health of the PeaShooter
    TextureManager* textures; ///< TextureManager to load the texture
    game* gameInstance; ///< Game instance to access the game's functions
    sf::Clock cooldownClock; ///< Clock to keep track of the cooldown
    bool cooldown = false; ///< Cooldown flag
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the PeaShooter
    std::unique_ptr<Animation> idleanimation; ///< Idle animation of the PeaShooter
    std::unique_ptr<Animation> Attackanimation; ///< Attack animation of the PeaShooter

    /**
     * @brief Sets the attack flag of the PeaShooter to true.
     */
    void setattack();

    /**
     * @brief Creates a bullet and adds it to the game instance's projectile container.
     */
    void shoot();

    /**
     * @brief Checks if there are any zombies in the PeaShooter's line of sight and if it should attack.
     * Takes the cooldown into account.
     * @return True if the PeaShooter should attack, otherwise false.
     */
    [[nodiscard]] bool shouldAttack() const;
};

#endif //PROJECTSFML_PEASHOOTER_H
