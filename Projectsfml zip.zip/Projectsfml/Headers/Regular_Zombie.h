/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_REGULAR_ZOMBIE_H
#define PROJECTSFML_REGULAR_ZOMBIE_H

#include "entity.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Textures.h"
#include "Animations.h"
#include "GameMap.h"
#include "game.h"
#include <memory>

class game;

/**
 * @class Regular_Zombie
 * @brief Enemy entity which has as main mission to reach the player's house. It has a certain amount of health and does a certain amount of damage.
 * If a plant is in its way, it will attack it in hopes of killing it. It will then continue to move towards the player's house to finish its mission.
 */
class Regular_Zombie : public entity {
public:
    /**
     * @brief Constructor for the Regular_Zombie class.
     * @param namein The name of the entity.
     * @param x The x-coordinate of the Regular_Zombie.
     * @param y The y-coordinate of the Regular_Zombie.
     * @param window The window to render the Regular_Zombie.
     * @param textures The texture manager to load the textures.
     * @param gameInstance The game instance to access the game's functions.
     */
    Regular_Zombie(std::string namein, int x, int y, sf::RenderWindow* window, TextureManager* textures, game* gameInstance);

    /**
     * @brief Destructor for the Regular_Zombie class.
     */
    ~Regular_Zombie() override;

    /**
     * @brief Updates the Regular_Zombie. Checks if it should attack and calls the attack function if necessary.
     * Flags it for deletion if it is dead. Updates the animation.
     */
    void update() override;

    /**
     * @brief Renders the Regular_Zombie, including its animation frame.
     */
    void renderentity() override;

    /**
     * @brief Returns the hitbox of the Regular_Zombie.
     * @return The hitbox of the Regular_Zombie.
     */
    [[nodiscard]] sf::Rect<float> getHitbox() const override;

    /**
     * @brief Changes the health of the Regular_Zombie. Flags it for deletion if it is dead.
     * @param dmg The amount of damage to apply.
     */
    void hpchange(int dmg) override;

private:
    sf::Clock clock; ///< Clock to keep track of the time
    bool attackFlag = false; ///< Flag to check if the Regular_Zombie is attacking
    int meleeRange = 50; ///< Range of the Regular_Zombie
    entity* target; ///< Target of the Regular_Zombie
    sf::Rect<float> hitbox; ///< Hitbox of the Regular_Zombie

    /**
     * @brief Moves the Regular_Zombie. Moves it to the left and checks if it is out of bounds. Flags the game for loss if it is out of bounds.
     */
    void move();

    /**
     * @brief Checks plant location, zombie attack range, and hitbox to determine if the Regular_Zombie should attack.
     * @return True if the Regular_Zombie should attack, otherwise false.
     */
    bool shouldAttack();

    /**
     * @brief If the Regular_Zombie should attack, it attacks the target.
     */
    void attack();

protected:
    int health = 100; ///< Health of the Regular_Zombie
    int speed = 2; ///< Speed of the Regular_Zombie
    int damage = 25; ///< Damage of the Regular_Zombie
    std::unique_ptr<sf::Sprite> sprite; ///< Sprite of the Regular_Zombie
    TextureManager* textures; ///< TextureManager to load the texture
    game* gameInstance; ///< Game instance to access the game's functions
    std::unique_ptr<Animation> Walkanimation; ///< Walk animation of the Regular_Zombie
    std::unique_ptr<Animation> Attackanimation; ///< Attack animation of the Regular_Zombie
};

#endif //PROJECTSFML_REGULAR_ZOMBIE_H
