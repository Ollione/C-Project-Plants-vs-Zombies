/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_GAME_H
#define PROJECTSFML_GAME_H

#include <SFML/Graphics.hpp>
#include <OpenGL.hpp>
#include "entity.h"
#include "Textures.h"
#include <vector>
#include "PeaShooter.h"
#include "GameMap.h"
#include "PeaShot.h"
#include "Sunflower.h"
#include "Wall.h"
#include "Mower.h"
#include <ctime>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include <memory>

class entity;
class Regular_Zombie; // Forward declaration
class PeaShooter;
class GameMap;
class PeaShot;
class Sunflower;
class Wall;
class Mower;
class Bucket_Zombie; // Forward declaration

/**
 * @class game
 * @brief The game class is the main class of the game which handles the game loop and the game logic. It also handles the rendering of the game.
 * Its main purpose is to update and render the game, handle the game logic and events. The game class connects all the other classes in the game.
 */
class game {
public:
    /**
     * @brief Constructor for the game class.
     */
    game();

    /**
     * @brief Destructor for the game class.
     */
    virtual ~game();

    /**
     * @brief Updates the game's components like entities and projectiles.
     */
    void update();

    /**
     * @brief Renders the game's components.
     */
    void render();

    /**
     * @brief Checks if the game is running.
     * @return True if the game is running, otherwise false.
     */
    [[nodiscard]] bool running() const;

    /**
     * @brief Adds a projectile to the game, which in this game is a peashot. Also includes pushing the projectile to the vector.
     * @param x The x-coordinate of the projectile.
     * @param y The y-coordinate of the projectile.
     * @param speed The speed of the projectile.
     * @param damage The damage of the projectile.
     */
    void addprojectile(int x, int y, int speed, int damage);

    /**
     * @brief Returns the reference to the entities vector so it can be used in other classes.
     * @return A reference to the entities vector.
     */
    std::vector<entity*>& getEntities();

    /**
     * @brief Adds money to the game and sets a max limit of 1000.
     * @param amount The amount of money to add.
     */
    void addMoney(int amount);

    /**
     * @brief Flags the game as over. This is used in other classes to signal the game is over.
     */
    void setGameOver();

    /**
     * @brief Checks if the game is over.
     * @return True if the game is over, otherwise false.
     */
    bool isGameOver();

private:
    sf::Clock zombieSpawnClock;    ///< Clock for the game
    sf::Clock zombieIncreaseClock; ///< Clock for the game
    sf::Clock bucketZombieSpawnClock;   ///< Clock for spawn
    sf::Clock TotalTime;    ///< Total time for the game
    int zombiesToSpawn = 0; ///< Zombies to spawn
    int bucketZombieSpawn = 0;  ///< Bucket zombies to spawn
    int Money = 1000;    ///< Money for the game
    sf::Font font;  ///< Font for the game
    sf::Text moneyText; ///< Text which will display the money
    sf::Text timerText; ///< Text which will display the time
    std::vector<entity*> entities;  ///< Vector of entities
    std::vector<PeaShot*> projectiles; ///< Vector of projectiles
    bool gameover = false;  ///< Boolean for game over
    std::unique_ptr<sf::RenderWindow> window;
    sf::Event event;
    std::unique_ptr<sf::Sprite> ui;
    std::unique_ptr<TextureManager> textures;
    std::unique_ptr<GameMap> map;

    /**
     * @brief Loops through the events of the window and handles them with the different cases.
     */
    void pollEvents();

    /**
     * @brief Initializes the variables of the game, called in the constructor.
     */
    void initVariables();

    /**
     * @brief Preloads the textures of the game to avoid a performance spike when the game is running and entities need to load new textures.
     */
    void PreloadTextures();

    /**
     * @brief Adds an enemy to the game and pushes it to the entities vector. The enemy is placed at a random lane and at the end of the lane.
     * @param num The type of enemy to add.
     */
    void addEnemy(int num);

    /**
     * @brief Places a hero in the game and pushes it to the entities vector. The hero is also placed in the map vector to keep track of the positions.
     * @param heroName The name of the hero to place.
     */
    void placeHero(std::string heroName);

    /**
     * @brief Function which detects if a projectile hits an enemy. If this is the case the enemy will take damage and the projectile will be flagged for delete.
     */
    void hitdetect();

    /**
     * @brief Adds the hero "PeaShooter" to the game and pushes it to the entities vector.
     * @param x The x-coordinate of the hero.
     * @param y The y-coordinate of the hero.
     * @param xindex The x-index in the map grid.
     * @param yindex The y-index in the map grid.
     */
    void addPeaShooter(int x, int y, int xindex, int yindex);

    /**
     * @brief Adds the hero "Sunflower" to the game and pushes it to the entities vector.
     * @param x The x-coordinate of the hero.
     * @param y The y-coordinate of the hero.
     * @param xindex The x-index in the map grid.
     * @param yindex The y-index in the map grid.
     */
    void addSunflower(int x, int y, int xindex, int yindex);

    /**
     * @brief Adds the hero "Wall" to the game and pushes it to the entities vector.
     * @param x The x-coordinate of the hero.
     * @param y The y-coordinate of the hero.
     * @param xindex The x-index in the map grid.
     * @param yindex The y-index in the map grid.
     */
    void addWall(int x, int y, int xindex, int yindex);

    /**
     * @brief Checks if the player can buy a hero. If the player has enough money, the function will return true and deduct the money.
     * @param heroName The name of the hero to buy.
     * @return True if the player can buy the hero, otherwise false.
     */
    bool buyhero(const std::string& heroName);

    /**
     * @brief Sells a hero. The function will remove the hero from the entities vector and the map vector, and add money to the player.
     * @param hero The hero entity to sell.
     */
    void sellhero(entity* hero);

    /**
     * @brief Loads the mowers to the game. The mowers are placed next to the house as a cheat death mechanic for that row.
     */
    void LoadMowers();

    /**
     * @brief Function that spawns zombies to the game. Zombies are spawned at a random lane and at the end of the lane.
     */
    void spawnZombies();

    /**
     * @brief Updates the projectiles in the game. Updates the projectiles' positions and checks if they are out of bounds.
     */
    void projectileUpdate();

    /**
     * @brief Loops through all entities in the game and updates them.
     */
    void entetiesUpdate();

    /**
     * @brief Loops through all entities and calls their render function.
     */
    void renderEntities();

    /**
     * @brief Loops through all projectiles and calls their render function.
     */
    void renderProjectiles();

    /**
     * @brief Initializes the text for the game with location, size, and font.
     */
    void initText();

    /**
     * @brief Renders the text for the game and implements setprecision to show the time in a more readable way.
     */
    void renderText();

    /**
     * @brief After the game is finished, this function renders the end screen with the amount of time the player managed to survive.
     */
    void gameOvertime();

    /**
     * @brief Renders the UI for the game. The UI is a background sprite that is rendered first and then the text is rendered on top of it.
     */
    void renederUI();

    /**
     * @brief Initializes the window for the game and returns the pointer to it.
     * @return A pointer to the initialized window.
     */
    static sf::RenderWindow* initWindow();

    /**
     * @brief Function that sells a hero at the mouse position. Loops through all entities and checks if the mouse position is on top of a hero.
     */
    void sellHeroAtMousePosition();
};

#endif //PROJECTSFML_GAME_H
