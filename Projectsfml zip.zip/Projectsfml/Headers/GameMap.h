/*
 * Written by: Oliver Olofsson
 * Miun id: olol2202
 * Project name: Plants vs Zombies Clone
 */

#ifndef PROJECTSFML_GAMEMAP_H
#define PROJECTSFML_GAMEMAP_H
#include "SFML/Graphics.hpp"
#include "Textures.h"
#include "entity.h"
#include <memory>

/**
 * @class GameMap
 * @brief Class that handles the map of the game. It places the hero on the map and handles the coordinates of the map. It also checks placement of plants and enemies.
 */
class GameMap {
public:
    /**
     * @brief Constructor for the GameMap class.
     * @param x The x-coordinate of the map.
     * @param y The y-coordinate of the map.
     * @param window The window to render the map.
     * @param textures The texture manager to load the textures.
     */
    GameMap(int x, int y, sf::RenderWindow *window, TextureManager *textures);

    /**
     * @brief Destructor for the GameMap class.
     */
    ~GameMap();

    /**
     * @brief Renders the main objects of the map like the grass and the base.
     */
    void renderMap();

    /**
     * @brief Initializes the textures of the map on their respective sprites.
     */
    void inittextures();

    /**
     * @brief Places the hero on the map at the x index and y index. Also takes the hero as an argument
     * so a pointer of the hero can be stored in the map container.
     * @param x The x index on the map.
     * @param y The y index on the map.
     * @param hero The hero to place on the map.
     */
    void placeHero(int x, int y, entity* hero);

    /**
     * @brief Gets the hero on the map at the x index and y index.
     * @param x The x index on the map.
     * @param y The y index on the map.
     * @return A pointer to the hero at the specified location.
     */
    entity* getHero(int x, int y);

    /**
     * @brief Gets the square's y index on the map depending on the y coordinate.
     * @param y The y coordinate.
     * @return The y index of the square.
     */
    int gettileindexY(int y);

    /**
     * @brief Gets the square's x index on the map depending on the x coordinate.
     * @param x The x coordinate.
     * @return The x index of the square.
     */
    int gettileindexX(int x);

    /**
     * @brief Gets the Pea Shooter y coordinate depending on the index. Used to place the plant on the map and
     * make sure it is placed on the right square later on. This function is used for other plants as well.
     * @param y The y index.
     * @return The y coordinate of the Pea Shooter.
     */
    int getPeaShooterYcord(int y);

    /**
     * @brief Gets the Pea Shooter x coordinate depending on the index. Used to place the plant on the map and
     * make sure it is placed on the right square later on. This function is used for other plants as well.
     * @param x The x index.
     * @return The x coordinate of the Pea Shooter.
     */
    int getPeaShooterXcord(int x);

    /**
     * @brief Gets the y index of friendly depending on the y coordinate.
     * @param y The y coordinate.
     * @return The y index of friendly.
     */
    int getFriendlytileindexY(int y);

    /**
     * @brief Gets the x index of friendly depending on the x coordinate.
     * @param x The x coordinate.
     * @return The x index of friendly.
     */
    int getFriendlytileindexX(int x);

    /**
     * @brief Gets the y coordinates for enemy depending on the index so the enemy can be placed on the lane connected to its index.
     * @param y The y index.
     * @return The y coordinates for the enemy.
     */
    int getEnemytileindexY(int y);

private:
    std::vector<std::vector<entity*>> map; ///< Hero locations on the map
    TextureManager* textures;   ///< TextureManager to load the textures
    sf::RenderWindow* window;   ///< Window pointer to render the graphics
    std::unique_ptr<sf::Sprite> spriteBase; ///< Base sprite
    std::unique_ptr<sf::Sprite> spriteGrass; ///< Grass sprite
};

#endif //PROJECTSFML_GAMEMAP_H
